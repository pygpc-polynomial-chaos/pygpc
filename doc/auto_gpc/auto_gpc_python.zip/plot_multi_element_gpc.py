"""
Modelling discontinuous model functions
=======================================
"""