"""
Parallel processing capabilities of pygpc
=========================================
"""