"""
Setting up a model
==================
Present abstract model class and refer to templates folder
"""