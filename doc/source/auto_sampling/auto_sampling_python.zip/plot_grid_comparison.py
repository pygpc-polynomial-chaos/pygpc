"""
Comparison of sampling schemes
==============================

ADD RESULTS OF PAPER HERE

"""

