"""
Validation of gPC approximation
===============================
validate_gpc_plot
pygpc.validate_gpc_mc
"""