"""
Introduction to generalized Polynomial Chaos (gPC)
==================================================
Introduction to gPC
"""