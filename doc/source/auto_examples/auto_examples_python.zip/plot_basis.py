"""
Polynomial basis functions
==========================
Introduction to polynomial basis functions
"""